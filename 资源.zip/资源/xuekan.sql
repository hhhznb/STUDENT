/*
Navicat MySQL Data Transfer

Source Server         : MySQL
Source Server Version : 80024
Source Host           : localhost:3306
Source Database       : xuekan

Target Server Type    : MYSQL
Target Server Version : 80024
File Encoding         : 65001

Date: 2023-05-30 11:18:59
*/

SET FOREIGN_KEY_CHECKS=0;
